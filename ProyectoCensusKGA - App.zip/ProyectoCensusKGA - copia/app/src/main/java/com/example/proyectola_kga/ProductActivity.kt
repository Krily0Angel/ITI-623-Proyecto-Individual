package com.example.proyectola_kga

import Controller.ProductController
import Entity.Product
import Util.Util
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate

class ProductActivity : AppCompatActivity() {

    private lateinit var txtId: EditText
    private lateinit var txtName: EditText
    private lateinit var txtDescription: EditText
    private lateinit var txtPrice: EditText
    private lateinit var txtQuantity: EditText
    private lateinit var txtCategory: EditText
    private lateinit var productController: ProductController
    private var isEditMode: Boolean = false
    private lateinit var menuItemDelete: MenuItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_product)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        productController = ProductController(this)

        txtId = findViewById<EditText>(R.id.txtID)
        txtName = findViewById<EditText>(R.id.txtNameProduct)
        txtDescription = findViewById<EditText>(R.id.txtDescription)
        txtPrice = findViewById<EditText>(R.id.txtPrice)
        txtQuantity = findViewById<EditText>(R.id.txtQuantity)
        txtCategory = findViewById<EditText>(R.id.txtCategory)

        val btnSearch = findViewById<ImageButton>(R.id.btnSearchId_product)
        btnSearch.setOnClickListener {
            searchProduct(txtId.text.trim().toString())
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_crud, menu)
        menuItemDelete = menu!!.findItem(R.id.mnu_delete)
        menuItemDelete.isVisible = isEditMode
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.mnu_save -> {
                if (isEditMode) {
                    Util.showDialogCondition(this,
                        getString(R.string.TextSaveActionQuestion),
                        { saveProduct() })
                } else {
                    saveProduct()
                }
                true
            }

            R.id.mnu_delete -> {
                Util.showDialogCondition(this,
                    getString(R.string.TextDeleteActionQuestion),
                    { deleteProduct() })
                true
            }

            R.id.mnu_cancel -> {
                cleanScreen()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun searchProduct(id: String) {
        try {
            val product = productController.getById(id)
            if (product != null) {
                isEditMode = true
                txtId.setText(product.id.toString())
                txtId.isEnabled = false
                txtName.setText(product.name)
                txtDescription.setText(product.description)
                txtPrice.setText(product.price.toString())
                txtQuantity.setText(product.quantity.toString())
                txtCategory.setText(product.category)
                menuItemDelete.isVisible = true
            } else {
                Toast.makeText(this, getString(R.string.MsgDataNoFound),
                    Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            cleanScreen()
            Toast.makeText(this, e.message.toString(), Toast.LENGTH_LONG).show()
        }
    }

    private fun cleanScreen() {
        isEditMode = false
        txtId.isEnabled = true
        txtId.setText("")
        txtName.setText("")
        txtDescription.setText("")
        txtPrice.setText("")
        txtQuantity.setText("")
        txtCategory.setText("")
        invalidateOptionsMenu()
    }

    private fun isValidationData(): Boolean {
        return txtId.text.trim().isNotEmpty()
                && txtName.text.trim().isNotEmpty()
                && txtDescription.text.trim().isNotEmpty()
                && txtPrice.text.trim().isNotEmpty()
                && txtQuantity.text.trim().isNotEmpty()
                && txtCategory.text.trim().isNotEmpty()
                && txtPrice.text.toString().toDoubleOrNull() != null
                && txtQuantity.text.toString().toIntOrNull() != null
    }

    private fun saveProduct() {
        try {
            if (isValidationData()) {
                if (productController.getById(txtId.text.toString().trim()) != null && !isEditMode) {
                    Toast.makeText(this, getString(R.string.MsgDuplicateDate),
                        Toast.LENGTH_LONG).show()
                } else {
                    val product = Product()
                    product.id = txtId.text.toString().trim()
                    product.name = txtName.text.toString().trim()
                    product.description = txtDescription.text.toString().trim()
                    product.price = txtPrice.text.toString().toDouble()
                    product.quantity = txtQuantity.text.toString().toInt()
                    product.category = txtCategory.text.toString().trim()
                    product.createdDate = LocalDate.now()

                    if (!isEditMode)
                        productController.addProduct(product)
                    else
                        productController.updateProduct(product)

                    cleanScreen()
                    Toast.makeText(this, getString(R.string.MsgSaveSuccess),
                        Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Datos incompletos",
                    Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, e.message.toString(),
                Toast.LENGTH_LONG).show()
        }
    }

    private fun deleteProduct() {
        try {
            productController.removeProduct(txtId.text.toString())
            cleanScreen()
            Toast.makeText(this, getString(R.string.MsgDeleteSuccess),
                Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, e.message.toString(),
                Toast.LENGTH_LONG).show()
        }
    }
}

